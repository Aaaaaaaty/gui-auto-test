module.exports = {
	host: 'http://10.2.45.110:3033'
}